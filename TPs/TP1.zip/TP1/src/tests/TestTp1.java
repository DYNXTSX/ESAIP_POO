package tests;

public class TestTp1 {
    public static void main(String[] args){
        TestTp1 testtp1 = new TestTp1();
        //testJoueur.test1();
        //testJoueur.test2();
        //testJoueur.test3();
        //testJoueur.test4();
    }


    public void test1(){
        System.out.println("TEST DE LA LECTURE D'UN ENTIER");
    }
}
